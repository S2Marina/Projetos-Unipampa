//algoritmo de kruskal
//agora vai

Aresta ** addHeap(Grafo* g, Aresta** heap, int tamanho);
void kruskal(Grafo* g);
void printSolucao(Aresta** solucao, int tamanho);
