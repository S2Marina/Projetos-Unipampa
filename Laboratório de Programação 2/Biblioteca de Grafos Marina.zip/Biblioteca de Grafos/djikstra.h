void djikstra(Grafo* g);
int pertenceSolucao(int chave, Aresta** solucao, int tamanho);