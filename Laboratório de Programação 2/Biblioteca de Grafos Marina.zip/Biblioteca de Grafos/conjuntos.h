void makeSet(int n, int *conj);
int findSet(int i, int* conj);
void uniao(int *conj, int i, int j);
void imprimir(int* conj, int n);
