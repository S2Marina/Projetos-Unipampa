void prim(Grafo* g);
Nodo * buscaNodo(int chave, Grafo * g);
void printSolucaoP(Aresta** solucao, int tamanho);
int testeSolucao(Aresta* a, int tamanho, Aresta** solucao);